import express from "express";
import "express-async-errors";
import pkg from 'body-parser';
// import dotenv from 'dotenv';
import { currentUserRouter } from "./routes/current-user.js";
import { signInRouter } from "./routes/signin.js";
import { signOutRouter } from "./routes/signout.js";
import { signUpRouter } from "./routes/signup.js";
const { json } = pkg;
import { errorHandler } from "./middlewares/error-hander.js";
// import { NotFoundError } from "./errors/no-find-errors.js";
import { dbRouter } from "./routes/db-route.js";
import { profileUpdateRouter } from "./routes/profile-update.js";
import { initProducer } from "./kafka/producer.js";

const app = express();

app.use( json() );

app.use( dbRouter );
app.use( currentUserRouter );
app.use( signInRouter );
app.use( signOutRouter );
app.use( signUpRouter );
app.use( profileUpdateRouter );

app.use( errorHandler );


const start = async () => {
  const PORT = 3000;
  try {
    // 1️⃣ Initialize Kafka producer
    await initProducer();
    console.log("Kafka Producer connected successfully!");

    // 2️⃣ Start Express server
    app.listen(PORT, () => {
      console.log(`Auth Service listening to port ${PORT}`);
    });

  } catch (err) {
    console.error("Failed to start Auth Service:", err);
    process.exit(1); // exit if Kafka can't connect
  }
};

// call the async start function
start();