import { kafka } from "./kafka.client.js";
import { TOPICS } from "./topics.js";
import type { UserRegisteredEvent } from "@shared/events/user-registered.event.v1.js";

const producer = kafka.producer();

export const initProducer = async () => {
  await producer.connect();
};

export const publishUserRegistered = async (
  event: UserRegisteredEvent
) => {
  await producer.send({
    topic: TOPICS.USERS_EVENTS,
    messages: [
      {
        key: event.user_id, // important for partitioning
        value: JSON.stringify(event),
      },
    ],
  });
};
