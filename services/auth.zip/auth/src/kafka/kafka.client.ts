import { Kafka } from "kafkajs";

export const kafka = new Kafka({
  clientId: process.env.SERVICE_NAME! ?? 'auth-service',
  brokers: ["kafka-srv:9092"],
});