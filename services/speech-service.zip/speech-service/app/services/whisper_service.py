import whisper
import torchaudio
# import soundfile as sk

torchaudio.set_audio_backend("soundfile")

class WhisperService:
    def __init__(self):
        self.model = whisper.load_model("small", device="cpu")

    def preprocess_audio(self, audio_path: str, output_path: str) -> str:
        waveform, sr = torchaudio.load(audio_path)
        # Convert to mono
        waveform = waveform.mean(dim=0, keepdim=True)
        # Resample to 16kHz
        if sr != 16000:
            waveform = torchaudio.transforms.Resample(orig_freq=sr, new_freq=16000)(waveform)
        # Save as 16-bit PCM WAV
        torchaudio.save(output_path, waveform, 16000, encoding="PCM_S", bits_per_sample=16)
        return output_path

    def transcribe(self, audio_path: str) -> dict:
        preprocessed_path = self.preprocess_audio(audio_path, "temp_16k_mono.wav")
        result = self.model.transcribe(
            preprocessed_path,
            language="de",
            task="transcribe",
            word_timestamps=True,
            verbose=False
        )
        return {"text": result["text"].strip(), "segments": result["segments"]}

whisper_service = WhisperService()


# import whisper

# class WhisperService:
#     def __init__(self):
#         self.model = whisper.load_model("small", device="cpu", fp16=False)

#     def transcribe(self, audio_path: str) -> dict:
#         result = self.model.transcribe(
#             audio_path,
#             language="de",
#             task="transcribe",
#             word_timestamps=True,
#             verbose=False
#         )
#         return {
#             "text": result["text"].strip(),
#             "segments": result["segments"]
#         }

# whisper_service = WhisperService()

# from faster_whisper import WhisperModel

# class WhisperService:
#     def __init__(self):
#         self.model = WhisperModel(
#             "small",
#             device="cpu",          # or "cuda"
#             compute_type="int8"    # faster & lighter
#         )

#     def transcribe(self, audio_path: str) -> dict:
#         segments, info = self.model.transcribe(
#             audio_path,
#             language="de",
#             word_timestamps=True
#         )

#         result_segments = []

#         for segment in segments:
#             result_segments.append({
#                 "start": segment.start,
#                 "end": segment.end,
#                 "text": segment.text.strip(),
#                 "words": [
#                     {
#                         "word": w.word,
#                         "start": w.start,
#                         "end": w.end,
#                         "probability": w.probability
#                     }
#                     for w in segment.words or []
#                 ]
#             })

#         return {
#             "text": " ".join(s["text"] for s in result_segments),
#             "segments": result_segments
#         }


# whisper_service = WhisperService()